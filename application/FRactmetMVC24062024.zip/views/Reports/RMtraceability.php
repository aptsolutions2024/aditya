<!DOCTYPE html>
<html lang="en">

<head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta name="viewport" content="width=device-width, height=device-height, initial-scale=1">
    <meta name="description" content="Interactive Tables and Data Grids for JavaScript.">
    <title>View Part Stock Details | Aditya</title>

    <!-- STYLESHEETS -->
    <!-- ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~--- -->

    <!-- Fonts [ OPTIONAL ] -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;700&family=Ubuntu:wght@400;500;700&display=swap" rel="stylesheet">

    <!-- Bootstrap CSS [ REQUIRED ] -->
    <link rel="stylesheet" href="<?php echo base_url() ?>public/assets/css/bootstrap.min.css">

    <!-- Nifty CSS [ REQUIRED ] -->
    <link rel="stylesheet" href="<?php echo base_url() ?>public/assets/css/nifty.min.css">

    <!-- Nifty Demo Icons [ OPTIONAL ] -->
    <link rel="stylesheet" href="<?php echo base_url() ?>public/assets/css/demo-purpose/demo-icons.min.css">

    <!-- Demo purpose CSS [ DEMO ] -->
    <link rel="stylesheet" href="<?php echo base_url() ?>public/assets/css/demo-purpose/demo-settings.min.css">

    <!-- Tabulator Style [ OPTIONAL ] -->
    <link rel="stylesheet" href="<?php echo base_url() ?>public/assets/css/newCss/jquery.dataTables.min.css">
    <link rel="stylesheet" href="<?php echo base_url() ?>public/assets/css/newCss/buttons.dataTables.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>public/assets/css/common_style.css">
    
</head>

<body class="jumping">

    <!-- PAGE CONTAINER -->
    <!-- ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ -->
    <div id="root" class="root mn--max hd--expanded">

        <!-- CONTENTS -->
        <!-- ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ -->
        <section id="content" class="content">
            <div class="content__header content__boxed overlapping">
                <div class="content__wrap">

                    <!-- Breadcrumb -->
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb mb-0">
                              <?php $this->load->view('Reports/Reportslinks'); ?>
                            <li class="breadcrumb-item"><a href="<?php echo base_url('PartMvmtDatewiseDetails');?>">Datewise Documents</a></li>
                            
                        </ol>
                    </nav>
                    <!-- END : Breadcrumb -->

                    

                    <p class="lead">
                       
                    </p>

                </div>

            </div>


            <div class="content__boxed">
                <div class="content__wrap">
                    <div class="card mb-3">
                        <div class="card-body">
  

                            <div class="row">
                            <h2 style="width: 82%;">RM Traceability</h2>
                            
                            </div>

                            <?php echo form_open('/RMtraceability', array('autocomplete' => 'off','class' => 'row g-3','id' => 'formSch')); ?>
                                   
                                   <div class="col-md-4">
                                        <label class="form-label">Part Name <label class="mandatory">*</label></label>
                                         <?php $pId= set_value('Part_Id');  $pname= set_value('Part_Search');?>
                                        <input type="hidden" id="Part_IdOnly" name="Part_Id" class="form-select Part_Id" value="<?=$pId;?>">
                                           <div class="autocomplete">
                                              <input type="search" id="Part_SearchOnly" name="Part_Search" class="form-control" value="<?=$pname;?>" onkeyup="searchPart(this.value,'Only','<?=base_url('getPartsBySearch')?>')">   
                                              <ul id="searchResultOnly" class="searchResult"></ul>   
                                           </div>  
                                            <?php echo form_error('Part_Search');?>  
                                          <?php echo form_error('Part_Id');?>  
                                    </div>
                                     <div class="col-md-3">
                                                           <label class="form-label">Invoice No<label class="mandatory">*</label></label>
                                                           <?php $invoice_no=(set_value('invoice_no'))?set_value('invoice_no'):"";?>
                                                           <input id="invoice_no" name="invoice_no" type="text" class="form-control" value="<?=$invoice_no;?>">
                                                           <?php echo form_error('invoice_no');?>
                                    </div>
                                    <div class="col-2" style="margin-top: auto;">
                                        <button type="submit" class="btn btn-primary" >Show</button>
                                    </div>
                            </form>
                                        <br><br>
                            
                            <div style="">
                             <table class="table" style="width:100%" id="example1">
                             <thead>
                                    <tr>
                                        <th>Sr No</th>
                                        <th>Process</th>
                                        <th>Document Type</th>
                                        <th>Document ID</th>
                                        <th>Record Date</th>
                                        <th>Record Creater ID</th>
                                    </tr>
                                  </thead>
                                  <tbody>
                             
                                
             <?php 
             $srno=0;
             foreach($report as $row){ ?>
                 
                     
                              <tr>       
                          <td><?= $srno++;$srno;?></td>
                          <td><?php
                          echo "Invoice";
                          ?></td>
                          <td><?php echo "Invoice";?></td>
                          <td><?=$row[id];?></td>
                          <td><?=date('d-m-Y',strtotime($row['date']));?></td>
                          <td>-</td>
                          <tr>
                 
                <?php   //Packing 2 records
                
                     $query=$this->db->query("SELECT `year`, `doc_year`, `tran_date`, `branch_id`, `mast_dpr_id`, `part_id`, `operation_id`,issue_doc_type,issue_doc_id,created_by ,issue_qty FROM  tran_dpr_stock where issue_doc_id ='$row[id]' and issue_doc_type = 'invoice'");   
                     $report1 = $query->result_array();
                       echo "<br><b>Report 2 - ************************</b><br>". $this->db->last_query(); 
                       echo "<pre>"; print_r($report1); echo "</pre>";
                       $mast_dpr_ids=[];
                      foreach($report1 as $r1){
                              $query2=$this->db->query("SELECT det_partsrcir_id  as doc_id ,op_id  as op_id,issue_qty,issue_doc_type, 'RCIR' as type,tran_date,created_by FROM  tran_partsrcir_stock where issue_doc_id in ($r1[mast_dpr_id]) and issue_doc_type = 'tran_dpr'
                            union all
                            SELECT mast_dpr_id  as doc_id,operation_id  as op_id,issue_qty,issue_doc_type,'DPR' as type,tran_date,created_by FROM  tran_dpr_stock where issue_doc_id in ($r1[mast_dpr_id]) and issue_doc_type = 'tran_dpr'");
                            $report2 = $query2->result_array();  
                             if ($report2['type']=='RCIR')
                             {
                                 
                                 echo "<br>In IF - RCIR ";
                        			//SELECT GROUP_CONCAT(received_doc_type SEPARATOR ',')  FROM tran_partsrcir_stock where det_partsrcir_id  =$res[doc_id] and received_qty > 0;
                                      $query3=$this->db->query("SELECT op_id, received_qty,received_doc_id,received_doc_type,tran_date FROM tran_partsrcir_stock where det_partsrcir_id  ='$r2[doc_id]' and received_qty > 0");   
                                      $report3 = $query3->result_array();
                                      echo "<br>". $this->db->last_query(); 
                                      echo "<pre>"; print_r($report3); echo "</pre>";
                                    foreach ($report3 as $r3)
                                   {
                                       
                                   }
                             }
                             else     if ($report2['type']=='DPR')
                             {
                                $query3=$this->db->query("SELECT det_partsrcir_id  as doc_id ,op_id  as op_id,issue_qty,issue_doc_type, 'RCIR' as type,tran_date,created_by FROM  tran_partsrcir_stock where issue_doc_id in ($report2[mast_dpr_id]) and issue_doc_type = 'tran_dpr'
                            union all
                            SELECT mast_dpr_id  as doc_id,operation_id  as op_id,issue_qty,issue_doc_type,'DPR' as type,tran_date,created_by FROM  tran_dpr_stock where issue_doc_id in ($report2[mast_dpr_id]) and issue_doc_type = 'tran_dpr'");
                   
                             }
                                 
                             }
                         
                             
                          
                         $mast_dpr_ids[]=$r1['mast_dpr_id']."";
                         }
                      $mastdprids=implode(",",$mast_dpr_ids);
 
                          
                       $query2=$this->db->query("SELECT det_partsrcir_id  as doc_id ,op_id  as op_id,issue_qty,issue_doc_type, 'RCIR' as type,tran_date,created_by FROM  tran_partsrcir_stock where issue_doc_id in ($mastdprids) and issue_doc_type = 'tran_dpr'
                            union all
                            SELECT mast_dpr_id  as doc_id,operation_id  as op_id,issue_qty,issue_doc_type,'DPR' as type,tran_date,created_by FROM  tran_dpr_stock where issue_doc_id in ($mastdprids) and issue_doc_type = 'tran_dpr'");
                            $report2 = $query2->result_array();  
                           echo "<br><b>Report 3 - ************************</b><br>". $this->db->last_query(); 
                           echo "<pre>"; print_r($report2); echo "</pre>";
          
                    echo "<br><b>Report 4 - ************************</b><br>";           
                    foreach ($report2 as $r2)
                    { ?>
                               <tr>       
                          <td><?= $srno++;$srno;?></td>
                          <td><?php
                          $operD=$this->getQueryModel->getOperation($r2['op_id']);
                          echo $operD['name'];
                          ?></td>
                          <td><?=$r2['issue_doc_type'];?></td>
                          <td><?=$r2['doc_id'];?></td>
                          <td><?=date('d-m-Y',strtotime($r2['tran_date']));?></td>
                          <td><?=$r2['created_by'];?></td>
                        <tr>  
                        
                        
                  <?php        
                            if ($r2['type']=='RCIR')
                             {
                                 
                                 echo "<br>In IF - RCIR ";
                        			//SELECT GROUP_CONCAT(received_doc_type SEPARATOR ',')  FROM tran_partsrcir_stock where det_partsrcir_id  =$res[doc_id] and received_qty > 0;
                                      $query3=$this->db->query("SELECT received_qty,received_doc_id,received_doc_type,tran_date FROM tran_partsrcir_stock where det_partsrcir_id  ='$r2[doc_id]' and received_qty > 0");   
                                      $report3 = $query3->result_array();
                                      echo "<br>". $this->db->last_query(); 
                                      echo "<pre>"; print_r($report3); echo "</pre>";
                                    foreach ($report3 as $r3)
                                    { 
                                	 if ($r3[received_doc_type]=='dc_rcir')
                        					{
                        					
                        					}
                        			  else if ($r3[received_doc_type]=='p_movement')
                        					{
                        					}
                        			  else if ($r3[received_doc_type]=='O.B.')
                        					{
                        					}
                        			  else if ($r3[received_doc_type]=='stock_sdj')
                        					{
                        					}
                        			  else if ($r3[received_doc_type]=='supl_pmovement')
                        					{
                        					}
                        			  else if ($r3[received_doc_type]=='qc_rework')
                        					{
                        					}
                        			  else if ($r3[received_doc_type]=='p_rcir')
                        					{
                        					}
                                  } 
                          
                            }
                            else if ($r2['type']=='DPR')
                            {
                                  echo "<br>In IF - RCIR ";
                                    
                            }
                         }
                }
             
             ?>
                      
                 </tbody>
            </table>  
           
            </div>

        </div>
    </div>

                </div>
            </div>

            <?php  $this->load->view('/include/footer'); ?>

        </section>

        <!-- ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ -->
        <!-- END - CONTENTS -->

       <?php  $this->load->view('/include/sidebar'); ?>

                

            </div>
        </nav>
        <!-- ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ -->
        <!-- END - MAIN NAVIGATION -->

        

    </div>
    <!-- ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ -->
    <!-- END - PAGE CONTAINER -->

    <!-- SCROLL TO TOP BUTTON -->
    <div class="scroll-container">
        <a href="#root" class="scroll-page rounded-circle ratio ratio-1x1" aria-label="Scroll button"></a>
    </div>
    <!-- ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ -->
    <!-- END - SCROLL TO TOP BUTTON -->



    <!-- JAVASCRIPTS -->
    <!-- ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ -->

    <!-- Popper JS [ OPTIONAL ] -->
    <script src="<?php echo base_url() ?>public/assets/vendors/popperjs/popper.min.js" defer></script>

    <!-- Bootstrap JS [ OPTIONAL ] -->
    <script src="<?php echo base_url() ?>public/assets/vendors/bootstrap/bootstrap.min.js" defer></script>

    <!-- Nifty JS [ OPTIONAL ] -->
    <script src="<?php echo base_url() ?>public/assets/js/nifty.js" defer></script>

    <!-- Nifty Settings [ DEMO ] -->
    <!-- <script src="<?php echo base_url() ?>public/assets/js/demo-purpose-only.js" defer></script> -->

   
    <!-- Initialize [ SAMPLE ] -->
    <script src="<?php echo base_url() ?>public/assets/js/newJs/jquery-3.5.1.js"></script>
    <script src="<?php echo base_url() ?>public/assets/js/newJs/jquery.dataTables.min.js"></script>
    <script src="<?php echo base_url() ?>public/assets/js/newJs/dataTables.buttons.min.js"></script>
    <script src="<?php echo base_url() ?>public/assets/js/newJs/pdfmake.min.js"></script>
    <script src="<?php echo base_url() ?>public/assets/js/newJs/jszip.min.js"></script>
    <script src="<?php echo base_url() ?>public/assets/js/newJs/vfs_fonts.js"></script>
    <script src="<?php echo base_url() ?>public/assets/js/newJs/buttons.html5.min.js"></script>
    <script src="<?php echo base_url() ?>public/assets/js/newJs/buttons.print.min.js"></script>
    <script src="<?php echo base_url() ?>public/assets/js/common_script.js"></script> 
   

<script>
$(document).ready(function() {
 
      $('#example1').DataTable( {
        dom: 'Bfrtip',
       "bPaginate": false,
    } );
    
} );



</script>
</body>

</html>