<?php
defined('BASEPATH') OR exit('No direct script access allowed');
error_reporting(0);
class ReportsController extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->model('Reports/ReportsModel');
		$this->load->model('getQuery/getQueryModel');
	}
    public function SchVSDisPatchByCust(){
         // print_r($_POST);
         
	   // $this->form_validation->set_rules('Customer_Id', 'Customer Name', 'trim|required');
	    $this->form_validation->set_rules('date', 'date', 'trim|required');
		$this->form_validation->set_error_delimiters('<div class="text-danger" style="text-align: left;margin-left: 5px;">', '</div>');
		
		if ($this->form_validation->run() == TRUE) {
	    $Customer_Id    = $_POST['Customer_Id'];
	    $date      = $_POST['date'];
	    $fromDate 	= date("Y-m", strtotime($date)); 
	
		   $data['getScheduleQtyInvoiceQtyAll'] = $this->getQueryModel->getScheduleQtyInvoiceQtyAll_ByCust($Customer_Id,$fromDate);
		   
	
		}
		$data['getCustName'] 		= $this->getQueryModel->getCustName();
		$this->load->view('Reports/SchVSDisPatchByCust',$data);
    }
    public function getCSchVSDischart(){
          $getCSchVSDischart = $this->getQueryModel->getCSchVSDischart();
          
       	if(!empty($getCSchVSDischart)){
	   	  echo json_encode($getCSchVSDischart);  
	   	}else{
	   	    echo 0;
	   	}
    }
     public function totalSchCompletion(){
          $totalSchCompletion = $this->getQueryModel->totalSchCompletion();
          
       	if(!empty($totalSchCompletion)){
	   	  echo json_encode($totalSchCompletion);  
	   	}else{
	   	    echo 0;
	   	}
    }
    public function totalDispatch(){
         $totalDispatch = $this->getQueryModel->totalDispatch();
          
       	if(!empty($totalDispatch)){
	   	  echo json_encode($totalDispatch);  
	   	}else{
	   	    echo 0;
	   	}  
    }
     public function totalDispatchInRS(){
         $totalDispatchInRS = $this->getQueryModel->totalDispatchInRS();
          
       	if(!empty($totalDispatchInRS)){
	   	  echo json_encode($totalDispatchInRS);  
	   	}else{
	   	    echo 0;
	   	}  
    }
    public function SchVSDesPatchR()
	{
	   // print_r($_POST);
	    $this->form_validation->set_rules('schedule_from_date', 'schedule_from_date', 'trim|required');
		$this->form_validation->set_rules('schedule_to_date', 'schedule_from_date', 'trim|required');
		//$this->form_validation->set_rules('Part_Id', 'Part_Id name', 'trim|required');
	   //$this->form_validation->set_rules('Part_Search', 'Part Name', 'trim|required');
		
		$this->form_validation->set_error_delimiters('<div class="text-danger" style="text-align: left;margin-left: 5px;">', '</div>');
		if ($this->form_validation->run() == TRUE) {
	    $Part_Id    = $_POST['Part_Id'];
	    $fromd      = $_POST['schedule_from_date'];
	    $fromDate 	= date("Y-m-d", strtotime($fromd)); 
	    $tod        = $_POST['schedule_to_date'];
	    $toDate 	= date("Y-m-t", strtotime($tod)); 

		if(!empty($Part_Id))
		{
		   $r1 = $this->ReportsModel->getScheduleQty($Part_Id,$fromDate,$toDate);
		   $data['getScheduleQty'] = (!empty($r1)) ? json_encode($r1) : 0;
		
		   	
		   $r2 = $this->ReportsModel->getInvoiceQty($Part_Id,$fromDate,$toDate);
		   $data['getInvoiceQty'] = (!empty($r2)) ? json_encode($r2) : 0;
		
		}else
		{
		   $data['getScheduleQtyInvoiceQtyAll'] = $this->ReportsModel->getScheduleQtyInvoiceQtyAll($fromDate,$toDate);
		}
		}
		$this->load->view('Reports/ScheduleVSDesPatchR',$data);
	} 
	public function OperPerformanceR(){
        $data['Getoperators'] = $this->getQueryModel->GetusersOperator();
		$this->load->view('Reports/operatorPerReport',$data);
	}

	public function showOPereport(){
		$Id=base64_decode($_GET['id']);
		$frm_date=$_GET['fromDate'];
		$to_date=$_GET['toDate'];
       
        $data['OperatorsDetails'] = $this->getQueryModel->getPerformData($Id,$frm_date,$to_date);
        $data['getPerformDataPartWiseSummary'] = $this->getQueryModel->getPerformDataPartWiseSummary($Id,$frm_date,$to_date);
         $data['getPerformDataOperatorSummary'] = $this->getQueryModel->getPerformDataOperatorSummary($Id,$frm_date,$to_date);
        
		$this->load->view('Reports/showOPereport',$data);
	}
   public function operatorPersummDashboard(){
          $getOperPerSummDashboard = $this->getQueryModel->getOperPerSummDashboard();
          
       	if(!empty($getOperPerSummDashboard)){
	   	  echo json_encode($getOperPerSummDashboard);  
	   	}else{
	   	    echo 0;
	   	}
   }
	public function predispatchIR(){
          $Id=base64_decode($_GET['ID']);
          $data['getPartNameById'] = $this->getQueryModel->getPartsById($Id);
          $data['companyDetails']     = $this->getQueryModel->companyDetails();
          $data['getQCById'] 			= $this->getQueryModel->getQCById($Id);
          	$this->load->view('Reports/preDispatchIReport',$data);
	}
	public function RMStockDetails(){
	    $this->form_validation->set_rules('from_date', 'From date', 'trim|required');
		$this->form_validation->set_rules('to_date', 'To date', 'trim|required');
		$this->form_validation->set_rules('branch_id', 'branch name', 'trim|required');
				$this->form_validation->set_rules('rm_id', 'RM name', 'trim|required');
		$this->form_validation->set_error_delimiters('<div class="text-danger" style="text-align: left;margin-left: 5px;">', '</div>');
		 	$data['getRawMaterial']   = $this->getQueryModel->getRawMaterial();
		 	$data['getBranch']        = $this->getQueryModel->getBranch();
		if ($this->form_validation->run() == TRUE) {
           $data['RMStockDetails'] = $this->getQueryModel->getRMStockDetails();
		}
         $this->load->view('Reports/RMStockDetails',$data); 
	}
	
	
	public function RMStockSummary(){
	//error_reporting(E_ALL);
	
        	$data['to_date']=$to_date=($_POST['to_date'])?$_POST['to_date']:date('Y-m-d');
          $this->load->view('Reports/rmStockSummary',$data);
	}
	public function PartStockDetails(){
	 
	//	$this->form_validation->set_rules('from_date', 'From date', 'trim|required');
		$this->form_validation->set_rules('to_date', 'To Date', 'trim|required');
		$this->form_validation->set_rules('Part_Search', 'Part Name', 'trim|required');
		
		$this->form_validation->set_error_delimiters('<div class="text-danger" style="text-align: left;margin-left: 5px;">', '</div>');
		
       
        $data=[];
		if ($this->form_validation->run() == TRUE) {
		    $data['partStockSummary']  = $this->getQueryModel->partStockSummary('Single');
		}
          $this->load->view('Reports/PartStockDetails',$data);
	}
	public function AllPartStockDetails(){

		$this->form_validation->set_rules('to_date', 'To Date', 'trim|required');
		$this->form_validation->set_error_delimiters('<div class="text-danger" style="text-align: left;margin-left: 5px;">', '</div>');
       
        $data=[];
		if ($this->form_validation->run() == TRUE) {
		    $data['partStockSummary']  = $this->getQueryModel->partStockSummary('ALL');
		}
          $this->load->view('Reports/AllPartStockDetails',$data);
	}
	public function SchedulePlanningR(){ 
		
		$data['SSDetails'] = $this->getQueryModel->getSupplierProdPlanning();	  
		$this->load->view('Reports/SchedulePlanningR',$data);
	}
	public function getScrapStkChart(){
	   	$getScrapStock= $this->getQueryModel->getScrapStkForBChart(); 
	   //	print_r($getScrapStock);
	   	if(!empty($getScrapStock)){
	   	  echo json_encode($getScrapStock);  
	   	}else{
	   	    echo 0;
	   	}
	   	
	
	}
  //created on 23-05-2023 by Asharani
  public function ScrapStockR()
	{ 
	    $data=[];
	   if(isset($_POST["export_data"])) {	
		$data['getScrapStockDet'] = $this->getQueryModel->getScrapStockDet();
		$Scrapdata=[];
        	if(!empty($data['getScrapStockDet'])){ 
                        $count=0; // print_r($getScrapStockDet);
                        foreach($data['getScrapStockDet'] as $res1){
                            $count++;
                            $rmdet = $this->getQueryModel->getRawMaterialbyrmid($res1['rm_id']);
                      
                            $branchD = $this->getQueryModel->getBranchbyId($res1['branch_id']);
                            
                            $Scrapdata[] = array(
        						'Sr_No' 			=> $count, 
        						'Date' 	            => $res1['date'], 
        						'Branch_Name' 		=> $branchD['name'], 
        						'RM_ID' 			=> $res1['rm_id'], 
        						'RM_Name' 			=> $rmdet['name'], 
        						'Type' 				=> $res1['type'], 
        						'Issue_Qty' 		=> $res1['issue_qty'], 
        						'Issue_Doc_Type' 	=> $res1['issue_doc_type'], 
        						'Issue_Doc_ID' 		=> $res1['issue_doc_id'], 
        						'Received_Qty' 		=> $res1['received_qty'], 
        						'Received_Doc_Type' => $res1['received_doc_type'],
        						'Received_Doc_ID'   => $res1['received_doc_id']
        						);
                        }
        	}
       //for download/export file to .xls format 
             $filename = "Scrapstock_export_".date('Ymd') . ".xls";			
        header("Content-Type: application/vnd.ms-excel");
        header("Content-Disposition: attachment; filename=\"$filename\"");	
        $show_coloumn = false;
        if(!empty($Scrapdata)) {
          foreach($Scrapdata as $record) {
        	if(!$show_coloumn) {
        	  // display field/column names in first row
        	  echo implode("\t", array_keys($record)) . "\n";
        	  $show_coloumn = true;
        	}
        	echo implode("\t", array_values($record)) . "\n";
          }
        }
        	exit;  
        }
		
		$this->load->view('Reports/ScrapStockR',$data);
	}
	
 //Added by Asharani for invoice print : 27-06-2023
  public function printInvDispatchR(){
          $Id=base64_decode($_GET['ID']);
          $PartId=base64_decode($_GET['PartId']);
          $data['getPartNameById'] = $this->getQueryModel->getPartsById($PartId);
          $data['companyDetails']       = $this->getQueryModel->companyDetails();
          $data['getInvDetailsforR']=$this->getQueryModel->getInvDetailsforReport($Id);
          $data['getQCById'] 			= $this->getQueryModel->getQCPDRByInvDetId($Id);
          $this->load->view('Reports/printInvDispatchR',$data);
  }
  
   //Added by Asharani for Inprocess Dpr QC  Report : 27-06-2023
   
  public function InprocessDprQCR(){
      $data=array();
           $this->form_validation->set_rules('from_date', 'From date', 'trim|required');
		   $this->form_validation->set_rules('to_date', 'To date', 'trim|required');
		   $this->form_validation->set_rules('branch_id', 'branch name', 'trim|required');
		   // $this->form_validation->set_rules('rm_id', 'RM name', 'trim|required');
	  	$this->form_validation->set_error_delimiters('<div class="text-danger" style="text-align: left;margin-left: 5px;">', '</div>');
		 	//$data['getRawMaterial']   = $this->getQueryModel->getRawMaterial();
		 	$data['getBranch']        = $this->getQueryModel->getBranch();
		if ($this->form_validation->run() == TRUE) {
           $data['getDPRdate'] = $this->getQueryModel->getDPRByDatefrto();
		}
         $this->load->view('Reports/InprocessDprQCR',$data); 
  }  
  
  
  //Added by Asharani for Incoming Part QC Report : 02-11-2023
  
  public function IncomingPartQCR(){
           $data=array();
           $this->form_validation->set_rules('from_date', 'From date', 'trim|required');
		   $this->form_validation->set_rules('to_date', 'To date', 'trim|required');
		   $this->form_validation->set_rules('branch_id', 'branch name', 'trim|required');
		   // $this->form_validation->set_rules('rm_id', 'RM name', 'trim|required');
	      $this->form_validation->set_error_delimiters('<div class="text-danger" style="text-align: left;margin-left: 5px;">', '</div>');
		 	//$data['getRawMaterial']   = $this->getQueryModel->getRawMaterial();
		 	$data['getBranch']        = $this->getQueryModel->getBranch();
		    $data['companyDetails']       = $this->getQueryModel->companyDetails();
		if ($this->form_validation->run() == TRUE) {
           $data['getPartQC'] = $this->getQueryModel->getIncomingQCDatefrto();
		}
         $this->load->view('Reports/IncomingPartQCR',$data); 
  }
  
   //Added by Asharani for Inprocess Dpr QC  Report : 13-07-2023
	public function RMConsumptionR(){
	    
	    $this->form_validation->set_rules('from_date', 'From date', 'trim|required');
		$this->form_validation->set_rules('to_date', 'To date', 'trim|required');
		//$this->form_validation->set_rules('branch_id', 'branch name', 'trim|required');
		//$this->form_validation->set_rules('rm_id', 'RM name', 'trim|required');
		$this->form_validation->set_error_delimiters('<div class="text-danger" style="text-align: left;margin-left: 5px;">', '</div>');
		if ($this->form_validation->run() == TRUE) {
		   $data=array();
           $result = $this->getQueryModel->RMConsumpDetails();
            	if(!empty($result)){
	   	             $data['RMConsumpDetails'] = json_encode($result);  
        	   	}else{
        	   	    echo 0;
        	   	}
		}
         $this->load->view('Reports/RMConsumptionR',$data); 
	}
   public function getConsumablePieChart(){
	   
	
           $result = $this->getQueryModel->RMConsumpDetailsforPie();
          
            	if(!empty($result)){
	   	            echo  json_encode($result);  
        	   	}else{
        	   	    echo 0;
        	   	}
	      
	} 
	public function totalConsumedMaterial(){
	   
	
           $result = $this->getQueryModel->totalConsumedMaterial();
          
            	if(!empty($result)){
	   	            echo  json_encode($result);  
        	   	}else{
        	   	    echo 0;
        	   	}
	      
	}
	
	
	
	//Added by Asharani for Rejection Summary Report : 14-07-2023
	public function RejectionSummaryR(){
	    $this->form_validation->set_rules('from_date', 'From date', 'trim|required');
		$this->form_validation->set_rules('to_date', 'To date', 'trim|required');
		$this->form_validation->set_rules('Customer_Id', 'Customer name', 'trim|required');
	    $this->form_validation->set_rules('Part_Id', 'Part name', 'trim|required');
	    $this->form_validation->set_rules('Part_Search', 'Part name', 'trim|required');
		$this->form_validation->set_error_delimiters('<div class="text-danger" style="text-align: left;margin-left: 5px;">', '</div>');
		
		$data['getCustName'] 		= $this->getQueryModel->getCustName();
		if ($this->form_validation->run() == TRUE) {
            $data['getRejDPRSummary'] = $this->getQueryModel->getRejDPRSummary();
            $data['getRejRCIRSummary'] = $this->getQueryModel->getRejRCIRSummaryDetails();
		}
         $this->load->view('Reports/RejectionSummaryR',$data); 
	}
	public function RejSummaryDashboardR(){
	        $result = $this->getQueryModel->rejSummaryDashboardR();
            	if(!empty($result)){
	   	            echo  json_encode($result);  
        	   	}else{
        	   	    echo 0;
        	   	}
	}
   public function TranToolsDashboardR(){
       $result = $this->getQueryModel->tranToolsDashboardR();
         // print_r($result);
            	if(!empty($result)){
	   	            echo  json_encode($result);  
        	   	}else{
        	   	    echo 0;
        	   	}
   }
   
   	public function PartMvmtDatewiseDetails(){
	 

		$this->form_validation->set_rules('Part_Search', 'Part Name', 'trim|required');
		
		$this->form_validation->set_error_delimiters('<div class="text-danger" style="text-align: left;margin-left: 5px;">', '</div>');
		
       
        $data=[];
		if ($this->form_validation->run() == TRUE) {
		    $data['partStockDatewiseDetails']  = $this->getQueryModel->partStockDatewiseDetails();
		}
          $this->load->view('Reports/PartMvmtDatewiseDetails',$data);
	}
	
}

?>