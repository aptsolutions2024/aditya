<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class LoginController extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->model('Login/LoginModel');
		$this->load->model('getQuery/getQueryModel');
		$this->load->model('Management/ManagementModel');
	}


	public function index()
	{
	    $data['getBranch'] 		= $this->getQueryModel->getBranch();
		$this->load->view('Login/index',$data);
	}

	public function signIn()
	{
    $this->session->unset_userdata('unmsg');
    $this->session->unset_userdata('accountmsg');
		$this->form_validation->set_rules('branch_id', 'Branch', 'trim|required');
		$this->form_validation->set_rules('username', 'Username', 'trim|required');
		$this->form_validation->set_rules('password', 'Password', 'trim|required');
		$this->form_validation->set_rules('current_year', 'Current Year', 'trim|required');
		$this->form_validation->set_error_delimiters('<div class="text-danger" style="text-align: left;margin-left: 5px;">', '</div>');

		if ($this->form_validation->run() == TRUE) {
		     $branch_Role   = $this->input->post('branch_id');
		     $username      = $this->input->post('username');
		     $password      = $this->input->post('password');
		     $current_year  = $this->input->post('current_year');
           
           
           $roleBranch= explode(" / ",$branch_Role);
		   $roleIds = $roleBranch[0];
		   $branchIds = $roleBranch[1];
		   
		   $role_id     =$this->ManagementModel->getRolebyIdBYName($roleIds);
		   $branch_id   = $this->ManagementModel->getBranchbyIdBYName($branchIds);
		   
            $login 			= $this->LoginModel->login($username,$password);
            //$currYear 		= $this->LoginModel->getCurrentYear($branch_id['id']);
            $compDetails 		= $this->LoginModel->GetCompanyNmbyId($login['company_id']);
            $role               =$role_id['id'];
		    //print_r($login);exit;
           		if($login) {
           		

           			$logged_in_sess = array(
           				'id' 			=> $login['id'],
				        'name'  		=> $login['fullname'],
				        'username'  	=> $login['username'],
				        'email_id'  	=> $login['email_id'],
				        'role'  		=> $role,
				        'role_name'  	=> $roleIds,
				        'branch_id'     => $branch_id['id'],
				        'branch_name'   => $roleBranch[1],
				        'company_id'  	=> $compDetails['id'],
				        'company_name'  => $compDetails['name'],
				        'current_year'  => $current_year,
				        'dashboard'     => 0,
				        'logged_in' 	=> TRUE
					);
                
				//$role=$login['role'];
				 
				$this->session->set_userdata($logged_in_sess);
				redirect('/MangDashboard', 'refresh');
				/*if($role==1)
				{
				redirect('/MangDashboard', 'refresh');
				}else if($role==2)
				{
				redirect('/UserDashboard', 'refresh');
				}*/
				}
           		else {
           			$this->session->set_flashdata('unmsg', 'Incorrect username/password combination');
                redirect(base_url());
           		}
           	}else {
           			//$this->session->set_flashdata('unmsg', 'Incorrect username/password combination');
           			$this->index();
           		}
		
	}
	
	public function checkUserDetails()
	{
	    $result 	= $this->getQueryModel->checkUserDetails();
		$user_id = $result['id'];
		
		if(!empty($user_id))
		{
		   $res 	= $this->ManagementModel->getUserRole($user_id); 
		   //print_r($res);die;
		    $total=sizeof($res);
            if($total!=0){
                echo '<option value="">Select Role / Branch</option>';
                foreach($res as $ur)
                {
                    $BD = $this->ManagementModel->getBranchbyId($ur['branch_id']);
                    $RD = $this->ManagementModel->getRoleById($ur['role_id']);
                    
                    $details  = $RD['name'].' / '.$BD['name'];
                    echo '<option value="'.$details.'" >'.$details.'</option>';
                    
                }
            }
			
		}else
            {
               echo '<option value="">Incorrect username/password combination</option>'; 
            }
		
	}
	public function getCurrentYear()
	{
	    $branchId = $_POST['branchId'];
	    $roleBranch= explode(" / ",$branchId);
		  $roleIds = $roleBranch[0];
		 $branchName = $roleBranch[1];
	    $res 	= $this->getQueryModel->getYearByBranchBy($branchName); 
	   // print_r($res);die;
		  $total=sizeof($res);
            if($total!=0){
                //echo '<option value="">Select Year</option>';
                foreach($res as $cy)
                {
                    $current_year = $cy['current_year'];
                   echo '<option value="'.$current_year.'" >'.$current_year.'</option>';
                    
                }
            }else
            {
               echo '<option value="">Incorrect username/password combination</option>'; 
            }
		
	}
	public function logout()
    {
    	$this->session->unset_userdata('id');
  		$this->session->unset_userdata('name');
  		$this->session->unset_userdata('username');
  		$this->session->unset_userdata('user_type');
  		$this->session->unset_userdata('role');
  		$this->session->unset_userdata('logged_in');
  		$this->session->unset_userdata('dashboard');
  		
  		redirect(base_url());
	}
	
	//New code for branch change by Asharani - 26-05-2023
 
	  public function changeBranch(){
	  	
	      $this->load->view('Login/changeBranch');
	  }

	  public function getUserRoleBranchbyID(){

		   $user_id=$_SESSION['id'];
		   $res 	= $this->ManagementModel->getUserRole($user_id); 
		   //print_r($res);die;
		    $total=sizeof($res);
            if($total!=0){
                echo '<option value="">Select Role / Branch</option>';
                foreach($res as $ur)
                {
                    $BD = $this->ManagementModel->getBranchbyId($ur['branch_id']);
                    $RD = $this->ManagementModel->getRoleById($ur['role_id']);
                    
                    $details  = $RD['name'].' / '.$BD['name'];
                    echo '<option value="'.$details.'" >'.$details.'</option>';
                    
                }
            }			
	   }
	   
	 public function signInwithBrRole()	{
        $this->session->unset_userdata('unmsg');
        $this->session->unset_userdata('accountmsg');
      
		$this->form_validation->set_rules('branch_id', 'Branch', 'trim|required');	
		$this->form_validation->set_rules('current_year', 'Current Year', 'trim|required');
		$this->form_validation->set_error_delimiters('<div class="text-danger" style="text-align: left;margin-left: 5px;">', '</div>');

		if ($this->form_validation->run() == TRUE) {
		     $branch_Role   = $this->input->post('branch_id');
		     $current_year  = $this->input->post('current_year');
           
           
           $roleBranch= explode(" / ",$branch_Role);
		   $roleIds = $roleBranch[0];
		   $branchIds = $roleBranch[1];
		   
		   $role_id     =$this->ManagementModel->getRolebyIdBYName($roleIds);
		   $branch_id   = $this->ManagementModel->getBranchbyIdBYName($branchIds);
		   
            $login 			= $_SESSION['id'];   //as user id
            //$currYear 		= $this->LoginModel->getCurrentYear($branch_id['id']);
            $compDetails 		= $this->LoginModel->GetCompanyNmbyId($_SESSION['company_id']);
            $role               =$role_id['id'];
		    //print_r($login);exit;
           		if($login) {
           			$logged_in_sess1 = array(
           				'role'  		=> '',
           				'role_name'  	=> '',
				        'branch_id'     => '',
				        'branch_name'   => '',
				        'current_year'  => '',
				        'dashboard'     => '', 
					);
           			$this->session->unset_userdata($logged_in_sess1);		

           			$logged_in_sess = array(           				
				        'role'  		=> $role,
				        'role_name'  	=> $roleIds,
				        'branch_id'     => $branch_id['id'],
				        'branch_name'     => $roleBranch[1],
				        'current_year'  => $current_year,
				        'dashboard'     => 0, 
					);
                
				//$role=$login['role'];
				 
				$this->session->set_userdata($logged_in_sess);
				redirect('/MangDashboard');
				/*if($role==1)
				{
				redirect('/MangDashboard', 'refresh');
				}else if($role==2)
				{
				redirect('/UserDashboard', 'refresh');
				}*/
				}
           		else {
           			$this->session->set_flashdata('unmsg', 'Incorrect Role & Branch/Year combination');
                redirect(base_url('changeBranch'));
           		}
           	}else {
           			//$this->session->set_flashdata('unmsg', 'Incorrect username/password combination');
           			$this->changeBranch();
           		}
		
	}

}
