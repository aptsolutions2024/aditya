<!DOCTYPE html>
<html lang="en">

<head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta name="viewport" content="width=device-width, height=device-height, initial-scale=1">
    <meta name="description" content="Interactive Tables and Data Grids for JavaScript.">
    <title>View Part Stock Details | Aditya</title>

    <!-- STYLESHEETS -->
    <!-- ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~--- -->

    <!-- Fonts [ OPTIONAL ] -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;700&family=Ubuntu:wght@400;500;700&display=swap" rel="stylesheet">

    <!-- Bootstrap CSS [ REQUIRED ] -->
    <link rel="stylesheet" href="<?php echo base_url() ?>public/assets/css/bootstrap.min.css">

    <!-- Nifty CSS [ REQUIRED ] -->
    <link rel="stylesheet" href="<?php echo base_url() ?>public/assets/css/nifty.min.css">

    <!-- Nifty Demo Icons [ OPTIONAL ] -->
    <link rel="stylesheet" href="<?php echo base_url() ?>public/assets/css/demo-purpose/demo-icons.min.css">

    <!-- Demo purpose CSS [ DEMO ] -->
    <link rel="stylesheet" href="<?php echo base_url() ?>public/assets/css/demo-purpose/demo-settings.min.css">

    <!-- Tabulator Style [ OPTIONAL ] -->
    <link rel="stylesheet" href="<?php echo base_url() ?>public/assets/css/newCss/jquery.dataTables.min.css">
    <link rel="stylesheet" href="<?php echo base_url() ?>public/assets/css/newCss/buttons.dataTables.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>public/assets/css/common_style.css">
    <style>
    .textFToUpper{
            text-transform: capitalize;
    }
    </style>
</head>

<body class="jumping">

    <!-- PAGE CONTAINER -->
    <!-- ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ -->
    <div id="root" class="root mn--max hd--expanded">

        <!-- CONTENTS -->
        <!-- ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ -->
        <section id="content" class="content">
            <div class="content__header content__boxed overlapping">
                <div class="content__wrap">

                    <!-- Breadcrumb -->
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb mb-0">
                            <li class="breadcrumb-item"><a href="<?php echo base_url('MangDashboard');?>">Home</a></li>
                            <li class="breadcrumb-item"><a href="<?php echo base_url('AllPartStockDetails');?>">All Parts Stock Details</a></li>
                        </ol>
                    </nav>
                    <!-- END : Breadcrumb -->

                    <p class="lead">
                    </p>

                </div>

            </div>


            <div class="content__boxed">
                <div class="content__wrap">
                    <div class="card mb-3">
                        <div class="card-body">

                             <?php  error_reporting(0); if($_SESSION['createS']!='') {?>
                                        <div class="alert alert-success" role="alert">
                                            <?=$_SESSION['createS'];?>
                                        </div>
                                    <?php } ?>    

                            <div class="row">
                            <h2 style="width: 82%;">All Parts Stock Details</h2>
                            </div>

                            <?php echo form_open('/AllPartStockDetails', array('autocomplete' => 'off','class' => 'row g-3','id' => 'formSch')); ?>
                                    
                                    <div class="col-md-2">
                                       <label class="form-label">To Date<label class="mandatory">*</label></label>
                                       <?php $todate=set_value('to_date'); ?>
                                       <input id="to_date" name="to_date" type="date" class="form-control" value="<?php echo $todate; ?>" min="<?php echo getMinDate();?>" max="<?php echo getMaxDate();?>">
                                       <?php echo form_error('to_date');?>
                                    </div>
                                 
                                    
                                    <div class="col-2" style="margin-top: auto;">
                                        <button type="submit" class="btn btn-primary" >Show</button>
                                    </div>
                                        
                                        </form>

                                        <br><br>
                            
                            <div style="">
                     
                            <?php 
                        
                            if(!empty($partStockSummary)){  ?>
                            <br>
                             <div style="max-height:400px;overflow: auto;">
                                 <table class="table table-bordered" style="width:100%" id="example1">
                                       <thead>
                                       <!--<tr>-->
                                       <!--   <th colspan="8" style="text-align:center;">  Part Stock Details As on - <?=$todate;?></th>-->
                                       <!--</tr>    -->
                                    <tr>
                                        <th>Sr No</th>
                                        <th>Part ID</th>
                                        <th>Partno</th>
                                        <th>Part Name</th>
                                        <th>Branch</th>
                                        <th>Operation</th>
                                        <th>Location</th>
                                        <th>QTY</th>
                                         <th>Total</th>
                                   </tr>
                                  </thead>
                                  <tbody>
                                   <?php  
                                     //echo "<pre>"; print_r($partStockSummary);echo "</pre>";
                                   $finalstock=0;
                                   $srno=0;
                                   foreach ($partStockSummary as $key1 => $value1) {
                                       //print_r($value1);exit;
                                      $partTotal=0;
                                       $srno++;
                                       $cnt=0;
                                      // $arrayCnt=sizeof($value1);
                                     foreach ($value1 as $k => $val) {
                                         $cnt++;
                                      
                                      $branchD =  $this->getQueryModel->getBranchbyId($val['branch_id']);
                                      $operD=$this->getQueryModel->getOperation($val['op_id']);
                                      $PartD = $this->getQueryModel->getPartsById($val['part_id']);
                                     
                                      //if(round(abs($val['qty']),0)>0){
                                     
                                   ?>
                                   
                                <tr>
                                 <?php if($cnt==1){  ?>
                                   <td><?=$srno;?></td> 
                                   <td><?=$PartD['part_id'];?></td>
                                   <td><?=$PartD['partno'];?></td>
                                    <td class="textFToUpper"><?=$PartD['name'];?></td>
                                   <?php }else{ ?>
                                   <td></td> 
                                   <td></td> 
                                   <td></td> 
                                   <td></td> 
                                   <?php } ?>
                                  
                                   <td><?=$branchD['name'];?></td> 
                                   <td><?=$operD['name'];?></td>
                                   
                                      <td class="textFToUpper"><?php
                                      if($val['qty']>0 && $val['doc_type']!='RCIR'){
                                         //echo 1; 
                                            $branchD=  $this->getQueryModel->getBranchbyId(substr($val['move_from'],1,6));
                                              echo $branchD['name']; 
                                      }elseif($val['qty']>0 && $val['doc_type']=='RCIR'){
                                          //echo 2;
                                            $branchD=  $this->getQueryModel->getBranchbyId(substr($val['move_to'],1,6));
                                              echo $branchD['name']; 
                                      }
                                      elseif(substr($val['move_from'],0,1)=='B'){
                                          //echo 3;
                                            if(substr($val['move_to'],0,1)=='S'){
                                              $supplierD=  $this->getQueryModel->getSupplierById(substr($val['move_to'],1,6));
                                              echo $supplierD['name']; 
                                            }else{
                                              $branchD=  $this->getQueryModel->getBranchbyId(substr($val['move_to'],1,6));
                                              echo $branchD['name'];
                                            }
                                        }
                                        elseif(substr($val['move_to'],0,1)=='B'){
                                           //echo 4;
                                            if(substr($val['move_from'],0,1)=='S'){
                                               $supplierD=  $this->getQueryModel->getSupplierById(substr($val['move_from'],1,6));
                                               echo $supplierD['name']; 
                                            }else{
                                               $branchD=  $this->getQueryModel->getBranchbyId(substr($val['move_from'],1,6));
                                               echo $branchD['name'];
                                            }
                                        }
                                      
                                        ?></td>
                                         <td><?php echo (round(abs($val['qty']),0))?round(abs($val['qty'])):"-";
                                         $partTotal+=abs($val['qty']);
                                         $finalstock=$finalstock+abs($val['qty']);
                                         ?></td>
                                    <td></td>
                                </tr>
                                <?php
                                      //}
                                  } ?>
                                  
                                   <tr style="background:#4652eb0f;text-align:right;">
                                     <td></td>
                                     <td></td>
                                     <td></td>
                                     <td></td>
                                     <td></td>
                                     <td></td>
                                     <td></td>
                                     <td></td>
                                     <td><?=$partTotal?></td>
                                   </tr>
                               
                               <?php } ?>
                                </tbody>
                            </table>
                            </div>
                            <?php } ?>
                               <table class="table table_stripped"  style="text-align:center;">
                                <tr>
                                
                                     <th>Final Stock</th>
                         
                                </tr>
                                <tr>
                                 
                                    <td style="color: green;font-size: 24px;"><?=round($finalstock,2);?></td>
                                   
                                </tr>
                            </table>
                            </div>

                        </div>
                    </div>


                    

                </div>
            </div>

            <?php  $this->load->view('/include/footer'); ?>

        </section>

        <!-- ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ -->
        <!-- END - CONTENTS -->

       <?php  $this->load->view('/include/sidebar'); ?>

                

            </div>
        </nav>
        <!-- ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ -->
        <!-- END - MAIN NAVIGATION -->

        

    </div>
    <!-- ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ -->
    <!-- END - PAGE CONTAINER -->

    <!-- SCROLL TO TOP BUTTON -->
    <div class="scroll-container">
        <a href="#root" class="scroll-page rounded-circle ratio ratio-1x1" aria-label="Scroll button"></a>
    </div>
    <!-- ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ -->
    <!-- END - SCROLL TO TOP BUTTON -->



    <!-- JAVASCRIPTS -->
    <!-- ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ -->

    <!-- Popper JS [ OPTIONAL ] -->
    <script src="<?php echo base_url() ?>public/assets/vendors/popperjs/popper.min.js" defer></script>

    <!-- Bootstrap JS [ OPTIONAL ] -->
    <script src="<?php echo base_url() ?>public/assets/vendors/bootstrap/bootstrap.min.js" defer></script>

    <!-- Nifty JS [ OPTIONAL ] -->
    <script src="<?php echo base_url() ?>public/assets/js/nifty.js" defer></script>

    <!-- Nifty Settings [ DEMO ] -->
    <!-- <script src="<?php echo base_url() ?>public/assets/js/demo-purpose-only.js" defer></script> -->

   
    <!-- Initialize [ SAMPLE ] -->
    <script src="<?php echo base_url() ?>public/assets/js/newJs/jquery-3.5.1.js"></script>
    <script src="<?php echo base_url() ?>public/assets/js/newJs/jquery.dataTables.min.js"></script>
    <script src="<?php echo base_url() ?>public/assets/js/newJs/dataTables.buttons.min.js"></script>
    <script src="<?php echo base_url() ?>public/assets/js/newJs/pdfmake.min.js"></script>
    <script src="<?php echo base_url() ?>public/assets/js/newJs/jszip.min.js"></script>
    <script src="<?php echo base_url() ?>public/assets/js/newJs/vfs_fonts.js"></script>
    <script src="<?php echo base_url() ?>public/assets/js/newJs/buttons.html5.min.js"></script>
    <script src="<?php echo base_url() ?>public/assets/js/newJs/buttons.print.min.js"></script>
    <script src="<?php echo base_url() ?>public/assets/js/common_script.js"></script> 
   

<script>
$(document).ready(function() {
 
      $('#example1').DataTable( {
        dom: 'Bfrtip',
        "bSort": false,
          fixedHeader: {
        header: true,
    },
    paging: false,
        buttons: [
            'excel'
        ]
    } );
    
} );



</script>
</body>

</html>