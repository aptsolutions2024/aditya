<!DOCTYPE html>
<html lang="en">

<head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta name="viewport" content="width=device-width, height=device-height, initial-scale=1">
    <meta name="description" content="General form-control live preview. You can copy our examples and paste them into your project!">
    <title>Add Scrap Invoice | Aditya</title>

    <!-- STYLESHEETS -->
    <!-- ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~--- -->

    <!-- Fonts [ OPTIONAL ] -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;700&family=Ubuntu:wght@400;500;700&display=swap" rel="stylesheet">

    <!-- Bootstrap CSS [ REQUIRED ] -->
    <link rel="stylesheet" href="<?php echo base_url() ?>public/assets/css/bootstrap.min.css">

    <!-- Nifty CSS [ REQUIRED ] -->
    <link rel="stylesheet" href="<?php echo base_url() ?>public/assets/css/nifty.min.css">

    <!-- Nifty Demo Icons [ OPTIONAL ] -->
    <link rel="stylesheet" href="<?php echo base_url() ?>public/assets/css/demo-purpose/demo-icons.min.css">

    <!-- Demo purpose CSS [ DEMO ] -->
    <!-- <link rel="stylesheet" href="<?php echo base_url() ?>public/assets/css/demo-purpose/demo-settings.min.css"> -->
     <!-- Tabulator Style [ OPTIONAL ] -->
    <link rel="stylesheet" href="<?php echo base_url() ?>public/assets/css/newCss/jquery.dataTables.min.css">
    <link rel="stylesheet" href="<?php echo base_url() ?>public/assets/css/newCss/buttons.dataTables.min.css">
    <style>
        input#togglecheckbx {
              width: 19px;
               height: 19px;
        }
    </style>
</head>

<body class="jumping">

    <!-- PAGE CONTAINER -->
    <!-- ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ -->
    <div id="root" class="root mn--max hd--expanded">

        <!-- CONTENTS -->
        <!-- ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ -->
        <section id="content" class="content">
            <div class="content__header content__boxed rounded-0">
                <div class="content__wrap">

                    <!-- Breadcrumb -->
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb mb-0">
                           <li class="breadcrumb-item"><a href="<?= base_url(); ?>MangDashboard">Home</a></li>
                            <li class="breadcrumb-item active"><a href="<?= base_url('scrapInvoice'); ?>">Scrap Invoice</a></li>
                        </ol>
                    </nav>
                    <!-- END : Breadcrumb -->
                    <p class="lead">
                    </p>
                </div>
            </div>
          

            <div class="content__boxed">
                <div class="content__wrap">
                    
                     <?php 
                     if($_GET['Id'] ==''){ ?>
                    <h2 class="mb-3">Add Scrap Invoice</h2>
                    <?php } else { ?>
                    <h2 class="mb-3">Update Scrap Invoice</h2>
                    <?php } ?>


                    <section>
                        <div class="row">
                            <div class="col-md-12 mb-6">
                                <div class="card h-100">
                                    <div class="card-body">
                                       <?php error_reporting(0); if($_SESSION['createS']!='') {?>
                                        <div class="alert alert-success" role="alert">
                                            <?=$_SESSION['createS'];?>
                                        </div>
                                    <?php } ?>
                                        <!-- Block styled form -->
                                        <?php if($GetDPRById[0]['dpr_date']==''){  ?>
                                        <?php echo form_open('/createScrapInvoice', array('autocomplete' => 'off','class' => 'row g-3'));    ?>
                                    <?php } else {  ?>
                                        <?php echo form_open('/updateScrapInvoice', array('autocomplete' => 'off','class' => 'row g-3')); ?>
                                    <?php } 
                               
                                    ?>
                                   
                                        <form class="row g-3">
                                       
                                      
                                         <!--<div class="col-md-3"> -->
                                         <!-- <label for="" class="form-label">Select Date : <label class="mandatory">*</label></label>-->
                                         <!--<input type="date" name="txtDate" value=""  class="form-control txtDate" min="<?php echo getMinDate();?>" max="<?php echo getMaxDate();?>">-->
                                         <!--</div>-->
                                       
                                         <?php 
                                         if(!empty($GetDPRById)){
                                            $i=1;
                                            $j=30;
                                         foreach ($GetDPRById as $key => $value) {
                                         //print_r($value);
                                         $sum_iss_qty=0;
                                         $SumIssueQty = $this->GetQueryModel->getIssueQtybyDprID($value['id']);
                                         
                                         if(!empty($SumIssueQty)){
                                          $sum_iss_qty=$SumIssueQty['issue_qty'];   
                                         }
                                         ?> 
                                          <input type="hidden" name="editId[]" class="editId" value="<?= $value['id']; ?>">
                                         <div style="border: 1px dotted #df5645;margin-top: 15px;"></div>
                                        <div class="col-md-3">
                                            <input type="hidden" id="prod_plan_id"  value="<?= $value['prod_plan_id']; ?>"  name="prod_plan_id[]">
                                            <label for="" class="form-label">Select Part<label class="mandatory">*</label></label>
                                           <input type="hidden" class="part_ids1" name="id[]" value="<?= $value['id']; ?>">
                                           <input type="hidden" class="part_ids<?=$j;?>" name="part_ids[]" value="<?= $value[part_id]."@".$value['prod_plan_id']; ?>">
                                           <?php 
                                                $partid = $this->GetQueryModel->getPartsById($value['part_id']);
                                             
                                           ?>
                                            <select class="form-control parts<?=$j;?>" readonly name="txtpart[]" onchange="editpartsfn()" required>
                                                <option value="<?= $partid['part_id']; ?>"><?= $partid['name']; ?></option>
                                            </select>
                                        </div>  
                                          <div class="col-md-3">
                                            <label for="" class="form-label">Operations <label class="mandatory">*</label></label>
                                            <?php
                                            
                                            $operationname = $this->GetQueryModel->getOperation($value['operation_id']); 
                                            //echo "<br>Operation ID:".$value['operation_id']."   Operation Name:".$operationname;
                                             ?>
                                          <select class="form-control Operations<?=$j;?>" readonly onchange="operationfn(1)" required name="txtoperations[]">
                                               <option value="<?= $operationname['id']; ?>" <?php if($value['operation_id']==$operationname['id']) echo "selected";?>><?= $operationname['name']; ?></option>
                                            </select>
                                             <?php echo form_error('txttype');?>
                                        </div>
                                         <div class="col-md-3">
                                            <label for="" class="form-label">Tools <label class="mandatory">*</label></label>
                                                 <?php $getToolById = $this->GetQueryModel->getToolById($value['tool_id']); 
                                             ?>
                                              <select readonly class="form-control " onchange="txttools2(<?=$j;?>)" required name="txttools[]">
                                                <option value="<?= $getToolById['id']; ?>"><?= $getToolById['name']; ?></option>
                                            </select>
                                            
                                             <?php echo form_error('txttype');?>
                                        </div>
                                         <div class="col-md-3">
                                            <label for="" class="form-label">Machine <label class="mandatory">*</label></label>
                                            
                                          <select readonly class="form-control" required name="txtmachines[]">
                                                <option value="">Select Machine</option>
                                                <?php foreach ($Getmachine  as $key => $value5) 
                                                {
                                                     $selected = ($value['machine_id'] == $value5['id']) ? "selected" : "";
                                                    ?>
                                                <option <?= $selected; ?> value="<?= $value5['id']; ?>"><?= $value5['name']; ?></option>
                                                <?php }?>
                                            </select>
                                             <?php echo form_error('txttype');?>
                                        </div> 
                                           <div class="col-md-3">
                                            <label for="" class="form-label">Scrap Used <label class="mandatory">*</label></label>
                                            <input type="hidden" class="form-control" id="txtscrap<?=$j;?>" name="txtscrap[]" value="<?php echo trim($value['scrap_used']);?>">
                                          <select disabled class="form-control" id="txtscrap<?=$j;?>" required name="txtscrap[]">
                                              
                                                <option value="N" <?= ($value[scrap_used] == "N") ? "selected" : "" ?> >No</option>
                                                <option value="Y" <?= ($value[scrap_used] == "Y") ? "selected" : "" ?>>YES</option>
                                            </select>
                                             <?php echo form_error('txttype');?>
                                        </div>
                                          <div class="col-md-3">
                                            <label for="" class="form-label">Operator<label class="mandatory">*</label></label>

                                          <select  readonly class="form-control txtoperator" name="txtoperator[]" required>
                                                <option value="">Select Operator</option>
                                                <?php foreach ($Getusers as $key => $value4) 
                                                {
                                                     $selected = ($value['operator_id'] == $value4['id']) ? "selected" : "";
                                                    ?>
                                                <option <?= $selected; ?> value="<?= $value4['id']; ?>"><?= $value4['fname']; ?></option>
                                                        
                                                <?php } ?>
                                            </select>
                                             <?php echo form_error('txttype');?>
                                        </div>                                       
                                        <?php $readonlyqty=($value[qty]>0)?"readonly":"";?>
                                         <div class="col-md-2">
                                            <label for="" class="form-label">Work Hours<label class="mandatory">*</label></label>
                                            <input id="txthours"  name="txthours[]" type="text" maxlength="11"   style="text-transform: uppercase"   class="form-control" placeholder="Work Hours 00 Hours. 00 minutes" value="<?php echo set_value('txthours', $value[work_hours]); ?>" <?=$readonlyqty;?>>
                                            <?php echo form_error('txthours');?>
                                        </div>
                                        <div class="col-md-2">
                                            <label for="" class="form-label">Qty<label class="mandatory">*</label></label>
                                            <input id="txtQty<?=$j;?>" style="font-size: 14px;" name="txtQty[]" onfocus="qtyfn(<?=$j;?>)" onclick="qtyfn(<?=$j;?>)"   type="number" maxlength="11"   style="text-transform: uppercase"  class="form-control" placeholder="Qty" value="<?php echo set_value('txtQty', $value[qty]); ?>" <?=$readonlyqty;?>>
                                            <?php echo form_error('txtQty');?>

                                        </div>

                                         <div class="col-md-2">
                                            <label for="" class="form-label">Max Qty<label class="mandatory">*</label></label>
                                            <input id="txtMaxQty<?=$j;?>"  readonly type="number" maxlength="11"   style="text-transform: uppercase"  class="form-control" placeholder="MaxQty" value="">
                                          
                                        </div>
                                        <?php $j++;?>
                                         <div class="col-md-10">
                                            <label for="" class="form-label">Remark<label class="mandatory"></label></label>
                                            <textarea class="form-control" name="txtremark[]" placeholder="Remark" style="height: 10px;"> <?= (!empty($value)) ? $value[remarks] : "" ?></textarea>
                                        </div>
                                        <?php
                                     
                                        if($value[qty]>0  && $sum_iss_qty==0){ ?>
                                        <div class="col-md-1" align="center" style="margin-top: 39px;">
                                            <a href="javascript:void(0);" onclick="delRecord(<?=$value['id'];?>);">
                                                <img src="<?php echo base_url(); ?>public/assets/img/minus.png" alt="Remove" style="width: 42px;">
                                            </a>
                                        </div>
                                        <?php } ?>
                                       <br>
                                        <!-- ---------add-------- -->
                                       

                                    <?php  $i++; } }else{ ?>
                                        <!-- <div class="col-md-3">-->
                                          
                                        <!--    <label for="" class="form-label">Invoice No<label class="mandatory">*</label></label>-->
                                           
                                        <!--            <input type="text" class="form-control invoice_no" name="invoice_no" value="" onkeypress="return isDecimalNumber(event);">-->
                                        <!--</div>  -->
                                        <!--  <div class="col-md-3">-->
                                        <!--    <label for="" class="form-label">Quantity (Kgs) <label class="mandatory">*</label></label>-->
                                        <!--     <input type="text" class="form-control" name="quantity" value="" onkeypress="return isDecimalNumber(event);" >-->
                                        <!--</div>-->
                                        <!-- <div class="col-md-3">-->
                                        <!--    <label for="" class="form-label">Scrap Type <label class="mandatory">*</label></label>-->
                                        <!--      <select class="form-control txttools1" required name="type">-->
                                        <!--        <option value="NORMAL" >NORMAL</option>-->
                                        <!--        <option value="SS" >SS</option>-->
                                        <!--    </select>-->
                                            
                                        <!--</div>-->
                                         <div class="col-md-3">
                                            <label for="" class="form-label">Branch <label class="mandatory">*</label></label>
                                            
                                          <select class="form-control branch_id" required name="branch_id">
                                              <?php 
                                                  $getBranch = $this->getQueryModel->getBranch();
                                              ?>
                                                <option value="">Select branch</option>
                                                <?php foreach ($getBranch  as $key => $value5) { ?>
                                                <option  value="<?= $value5['id']; ?>"><?= $value5['name']; ?></option>
                                                <?php } ?>
                                            </select>
                                          
                                        </div> 
                                        <div class="col-md-2">
                                                  <button type="button" class="btn btn-primary" onclick="getScrapQty()" style="margin-top: 14%;">Show</button> 
                                        </div>
                                       
                                    <?php } ?>
                                    
                                               <div class="col-md-12 modal-footer">
                                         
                                         
                                               
                                    </div>
                                       <div class="row scrapData" style="overflow : auto;"></div>
                                    </form>
                                 
                                        <!-- END : Block styled form -->
                                    </div>
                                </div>
                            </div>
                            
                        </div>
                    </section>
                </div>
            </div>

            <?php  $this->load->view('/include/footer'); ?>

        </section>

        <!-- ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ -->
        <!-- END - CONTENTS -->

        <?php  $this->load->view('/include/sidebar'); ?>


            </div>
        </nav>
        <!-- ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ -->
        <!-- END - MAIN NAVIGATION -->


    </div>
    <!-- ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ -->
    <!-- END - PAGE CONTAINER -->
    <?php  $this->load->view('/include/jsPage'); ?>

<script type="text/javascript">


$(document).ready(function() {
    $('#example').DataTable( {
        dom: 'Bfrtip',
        pageLength: 25,
        buttons: [
            'csv', 'excel', 'pdf', 'print'
        ]
    } );
} );

function SelectAll(){
         var selected=$("#togglecheckbx").prop("checked");
         
          $('input[name="checkboxVal[]"]').each(function() {
              
             $('#example input[name="checkboxVal[]"]').prop('checked', selected);
            
         });
         calTotal();
}

function calTotal(){
    //alert("hello");
     var totalval=0;
    $('input[name="checkboxVal[]"]:checked').each(function() {
   
   var num=this.value;
   //console.log(parseFloat($('#scrapVal'+num).val()));
   totalval=(totalval + parseFloat($('#scrapVal'+num).val()));
   });
    $('#totscrapVal').val(totalval);
}

  function isDecimalNumber(evt) {
          var charCode = (evt.which) ? evt.which : evt.keyCode
          if (charCode == 46) {
          return true;
          }
          else if (charCode > 31 && (charCode < 48 || charCode > 57))
          return false;
          return true;
         }

    function CloseCustomer(removeNum) 
    {
        location.href = 'scrapInvoice';
    } 
    
    function getScrapQty(){
          var date =  $(".txtDate").val();
            var invoice_no =  $(".invoice_no").val();
              var branch_id =  $(".branch_id").val();
             $.ajax({
                url: "<?= base_url('getScrapbyvalue'); ?>",
                data: {date : date,invoice_no : invoice_no,branch_id:branch_id},
                type: "POST",
                success: function(data)
                {
                    $(".scrapData").html(data);
                     
                }
            });
      
    }
</script>

</body>

</html>