<?php
defined('BASEPATH') OR exit('No direct script access allowed');
error_reporting(E_ALL);
class PartStockAdjController extends CI_Controller {

	public function __construct(){
		parent::__construct();
	//	$this->load->model('PartStockAdjustment/PartStockAdjModel');
		$this->load->model('getQuery/getQueryModel');
	}


	public function view()
	{
        
            $this->form_validation->set_rules('Part_Search', 'part name', 'trim|required');
            $this->form_validation->set_rules('to_date', 'date', 'trim|required');
            $this->form_validation->set_rules('bstype', 'Branch/Suuplier', 'trim|required');
	    		
		    $this->form_validation->set_error_delimiters('<div class="text-danger" style="text-align: left;margin-left: 5px;">', '</div>');
		  $data['getBranch']        = $this->getQueryModel->getBranch();
    		if ($this->form_validation->run() == TRUE) {
    		            $bstype = $_POST['bstype']; 
    		            $pid = $_POST['Part_Id'];
    				    $data['getPartOpDet'] 	= $this->getQueryModel->getSupBranchByPart($pid,$bstype); 
                  		$this->load->view('PartStockAdj/view',$data);
    
    		}else{
    				$this->load->view('PartStockAdj/view',$data);
    		}
	
	}
	
	public function updatePartsStkAdj()
	{
	  // echo "<pre>";print_r($_POST); echo "</pre>";die;
	 	if(!empty($_POST['checkboxVal']))
		{
			foreach ($_POST['checkboxVal'] as $key => $value) 
			{
				$keys = $value;
				if($_POST['qty'][$keys]!="" && $_POST['qty'][$keys]!=0){
				$part_id 		= $_POST['partid'];
				$date           = $_POST['date']; 
				$op_id 			= $_POST['op_id'][$keys];
				$branch_id   	= $_POST['bsid'][$keys];
				$type   	    = $_POST['type'][$keys];
				$qty   		    = $_POST['qty'][$keys];
				$remarks   		= $_POST['remarks'][$keys];
				//$qty_in_kgs   	= $_POST['qty_in_kgs'][$keys];
				 
		       $isavailable 	= $this->getQueryModel->getTranPartAdjQtyCnt($part_id,$op_id,$branch_id,$type,$date);
		      
		      //echo "***COUNT:-".$isavailable;
		      
			 if($isavailable){	
			     
                   $UpdateDate = array(
                    'qty' 		        => $qty,
                    'remarks'           => $remarks,
                    'qty_in_kgs' 	    => 0,
                    'updated_by' 		=> $_SESSION['id'],
                    'updated_on' 		=> date("Y-m-d"),
                    );
                    $this->db->where(array('part_id'=>$part_id ,'op_id'=>$op_id ,'date'=>$date));
                    if($type=='B'){ 
                                     $this->db->where('branch_id',$branch_id);
                        
                    }else{           $this->db->where('supplier_id',$branch_id);}
                    
                    $this->db->update('tran_part_stockadj',$UpdateDate);
                    
                    //echo "<br>".$this->db->last_query();die;
			  }else{
			      
			   // `date`, `branch_id`, `supplier_id`, `part_id`, `op_id`, `qty`, `qty_in_kgs`, `created_by`, `created_on`, 
			   
			       $UpdateDate = array(
                    'date' 			=> $date,
                    'branch_id' 	=> ($type=='B')?$branch_id:"",
                    'supplier_id' 	=> ($type=='S')?$branch_id:"",
                    'part_id' 	    => $part_id,
                    'op_id' 	    => $op_id,
                    'qty' 		    => $qty,
                    'qty_in_kgs' 	=> 0,
                    'remarks'       => $remarks,
                    'created_by' 	=> $_SESSION['id'],
                    'created_on' 	=> date("Y-m-d"),
                    );
                    
                    $resid=$this->db->insert('tran_part_stockadj',$UpdateDate);
                    $newStkAdjId=$this->db->insert_id();
                    
                if($newStkAdjId){
                    //If quantity>0 then tran_partsrcir_mast/tran_partsrcir_details/tran_partsrcir_stock
                    if($type=='B'){
                        if($qty > 0){
                                /*
                                Case1 -  Branch   Qty > 0
                                parts_rcir 
                                branch_id= branch_id
                                move_from=branch_id
                                move to = branch_id
                                received_qty = qty
                                received_doc_type = "stock_adj"
                                received_doc_no = tran_stock
                                */
                                $move_from="B".$branch_id;
                                $move_to = "B".$branch_id;
                                $this->insertIntoPartsRCIR($newStkAdjId,$part_id,$op_id,$date,$qty,$move_from,$move_to,$branch_id);
                                
                        }elseif($qty < 0){
                            
                         /* case 2 - Branch qty < 0
                            parts_rcir 
                            branch_id= branch_id
                			move_from=branch_id
                			move to = branch_id
                			received_qty = qty
                			received_doc_type = "stock_adj"
                			received_doc_no = tran_stock */ 
                			  $move_from="B".$branch_id;
                                $move_to = "B".$branch_id;
                                $this->insertIntoPartsRCIR($newStkAdjId,$part_id,$op_id,$date,$qty,$move_from,$move_to,$branch_id);
                        }
                        
                    }elseif($type=='S'){
                        $supl_id=$branch_id;
                        if($qty > 0){
                            /*
                            case 3 - Ssupplierr and qty >0 
                            dc
                            branch_id - session branch_id
                            move_from- session branch_id
                            move to supplier id
                            issue_qty  = qty
                            op_id = 
                            issue_doc_type = "stock_adj"
                            issue_doc_id = tran_stock
                            */
                              $move_from="B".$_SESSION['branch_id'];
                              $move_to = "S".$supl_id;
                             $this->insertIntoDCStock($newStkAdjId,$part_id,$op_id,$date,$qty,$move_from,$move_to,$supl_id);     
                        }elseif($qty < 0){
                         /* Supplier and Qty <0			 
                            dc
                            branch_id - session branch_id
                            move_from- session branch_id
                            move to supplier id
                            issue_qty  = qty
                            op_id = 
                            issue_doc_type = "stock_adj"
                            issue_doc_id = tran_stock
			            */ 
			                  $move_from="B".$_SESSION['branch_id'];
                              $move_to = "S".$supl_id;
                             $this->insertIntoDCStock($newStkAdjId,$part_id,$op_id,$date,$qty,$move_from,$move_to,$supl_id); 
                        }
                    }
                  
                   
                    
			  }  // if($newStkAdjId) 
                    
                    
			 }  //else for new stock adj entry
			

		   }  //if($_POST['qty'][$keys]!="" && $_POST['qty_in_kgs'][$keys]!="")
		   
  	}  //Foreach checkbox value
  	
	    	 redirect('/PartsStkAdjustment');
	    	 
		}else{
		    
		    redirect('/PartsStkAdjustment');
		    
		}
	}
	public function insertIntoDCStock($newStkAdjId,$part_id,$op_id,$date,$qty,$move_from,$move_to,$supl_id){
	    	$postDate = array(
	    	    		        'branch_id ' 		=> $_SESSION['branch_id'],
                				'supplier_id' 		=> $supl_id,
                				'date' 				=> $date,
                				'year'				=> $_SESSION['current_year'],
                				'dc_no' 			=> 'stock_adj',
                				'created_by ' 		=> $_SESSION['id'],
                				'created_on ' 		=> date("Y-m-d H:i:s"),
                				);
                				
                		$resid1=$this->db->insert('tran_dc_mast',$postDate);
                        $mast_dc_id=$this->db->insert_id();
                            
                        $postDetails = array(
            				'mast_dc_id' 	    => $mast_dc_id,
            				'part_id' 			=> $part_id,
            				'op_id' 			=> $op_id,
            				'qty_in_kgs' 		=> 0,
            				'qty' 				=> $qty,
            				'parts_po_det_id' 	=> 0,
            				'created_by ' 		=> $_SESSION['id'],
            				'created_on ' 		=> date("Y-m-d"),
            				'remarks'           =>'stock_adj',
            				);
            		
            				$resid2=$this->db->insert('tran_dc_details',$postDetails);
                            $det_dc_id=$this->db->insert_id();
                            
                    // $det_partsrcir_id for issue_doc_id	
        		     $postStockDetails1 = array(
        				'mast_dc_id'  	     => $mast_dc_id,
        				'det_dc_id' 	     => $det_dc_id,
        				'part_id' 		     => $part_id,
        				'op_id' 		     => $op_id,
        				'year' 			     => $_SESSION['current_year'],
        				'doc_year' 		     => $_SESSION['current_year'],
        				'issue_qty' 	     => $qty,
        				'issue_doc_type'     => 'tran_dc',
        				'issue_doc_id'       => $det_partsrcir_id,
        				'branch_id'          => $_SESSION['branch_id'],
        				'move_from'          => $move_from,
        				'move_to'            => $move_to,
        				'created_by ' 	     => $_SESSION['id'],
        				'created_on ' 	     => date("Y-m-d"),
        				);
        		     $resid2=$this->db->insert('tran_dc_stock',$postStockDetails1);
	}
	public function insertIntoPartsRCIR($newStkAdjId,$part_id,$op_id,$date,$qty,$move_from,$move_to,$branch_id){
	  
                        	$postDate = array(
                            				'branch_id' 	=> $branch_id,
                                            'supplier_id' 	=> 0,
                            				'date'			=> $date,
                            				'year'			=> $_SESSION['current_year'],
                            				'challan_date' 	=> $date,
                            				'challan_no' 	=> 'stock_adj',
                            				'created_by ' 	=> $_SESSION['id'],
                            				'created_on ' 	=> date("Y-m-d"),
                            				);
			              $resid1=$this->db->insert('tran_partsrcir_mast',$postDate);
                          $mast_partsrcir_id=$this->db->insert_id();
                          
			              $postDetails = array(
                            				'mast_partsrcir_id' 	=> $mast_partsrcir_id,
                            				'tran_partspo_det_id' 	=> 0,
                            				'dc_det_id' 	        => 0,
                            				'part_id' 			    => $part_id,
                            				'op_id' 		        => $op_id,
                            				'qty' 				    => $qty,
                            				'qty_in_kgs' 		    => 0,
                            				'inprocess_loss_qty' 	=> 0,
                            				'qc_checked_by'         => '999999',
                            				'qc_remarks'            =>'stock_adj',
                            				'qc_checked_on'         => date("Y-m-d H:i:s"),
                            				'year ' 		        => $_SESSION['current_year'],
                            				'created_by ' 		    => $_SESSION['id'],
                            				'created_on ' 		    => date("Y-m-d H:i:s"),
                            				);
				     
				              $resid2=$this->db->insert('tran_partsrcir_details',$postDetails);
                              $det_partsrcir_id=$this->db->insert_id();
                          
						      $UpdateDate68 = array(
        									'part_id' 			    => $part_id,
        									'op_id' 		        => $op_id,
        									'mast_partsrcir_id' 	=> $mast_partsrcir_id,
        									'det_partsrcir_id' 	    => $det_partsrcir_id,
        						            'year' 				    => $_SESSION['current_year'],
        						            'doc_year' 			    => $_SESSION['current_year'],
        									'branch_id' 	    	=> $branch_id,
        									'move_from'             => $move_from,
        				                    'move_to'               => $move_to,
        				                    'received_qty' 		    => $qty,
        									'received_doc_id' 		=> $newStkAdjId,
        									'received_doc_type' 	=> 'stock_adj',
        									'created_by' 		    => $_SESSION['id'],
        									'updated_by' 		    => $_SESSION['id'],
								    );
						$result16 = $this->db->insert('tran_partsrcir_stock',$UpdateDate68);
						
	}
	public function getMoveRateDetails()
	{
	   // print_r($_POST);die;
	   // $res     = $this->getQueryModel->getMoveRateDetails();
	   $partId = $_POST['Part_Id'];
	   $opId = $_POST['Op_Id'];

	   if(!empty($partId))
	   {
	   $maxQ   = $this->getQueryModel->getCurrentOpQty($partId,$opId);
	    $array = array('max_qty'=>$maxQ);
	      echo json_encode($array);
	   }else
	   {
	       echo "0";
	   }
	    
	}
	
	public function add()
	{
		$id = base64_decode($_GET['ID']);
	//	$data['getProdfamily'] 	    = $this->getQueryModel->getProductfamily();
		$data['getRawMaterial']   = $this->getQueryModel->getRawMaterial();
		$data['getBranch']        = $this->getQueryModel->getBranch();
		$data['getPartMovement']        = $this->getQueryModel->getPartMovement($id);
		$this->load->view('PartsMovement/add',$data);
	}
	public function getStock()
	{
	    $rm_id = $_POST['rmId'];
	   $res   = $this->getQueryModel->getMovementRMStock($rm_id);
	   if($res['stock'] !='')
	   {
	   echo $res['stock'];
	   }else { echo '0';}
	}
	public function create()
	{
	    
	   $this->form_validation->set_rules('Part_Id', 'part', 'trim|required');
		$this->form_validation->set_rules('Op_Id', 'Operation', 'trim|required');
		$this->form_validation->set_rules('branch_id', 'branch', 'trim|required');
		$this->form_validation->set_rules('quantity', 'Qty', 'trim|required');
		$this->form_validation->set_error_delimiters('<div class="text-danger" style="text-align: left;margin-left: 5px;">', '</div>');
        $part_id = $this->input->post('Part_Id');
        $Op_Id = $this->input->post('Op_Id');
		if ($this->form_validation->run() == TRUE) {
		    $postDate = array(
				'part_id' => $this->input->post('Part_Id'),
				'op_id' => $this->input->post('Op_Id'),
				'qty' => $this->input->post('quantity'),
				'from_branch_id' => $_SESSION['branch_id'],
				'to_branch_id' => $this->input->post('branch_id'),
				'date' => $this->input->post('date'),
				'created_by ' => $_SESSION['id'],
				'created_on ' => date("Y-m-d"),
				);
			$partMovementId=$this->PartsMovementModel->addtranPMovement($postDate);
			
            $getPartOperationStock = $this->getQueryModel->getPartOperationStock($part_id,$Op_Id); 

                        
						if(!empty($getPartOperationStock))
						{
                            $dpr_qty= $this->input->post('quantity');
							foreach ($getPartOperationStock as $key => $value) 
							{
								$id 	                = $value['id'];
								$date 	                = $value['date'];
								$doc 	                = $value['doc'];
								$op_id 	                = $value['op_id'];
								$mast_id 	            = $value['mast_id'];
								$mast_partsrcir_id 	    = $value['mast_partsrcir_id'];
                            	$available_qty   	    = $value['max_qty'];
						        $dpr_qty                = ($dpr_qty != "") ? $dpr_qty : 0;
								if($doc == "dpr")
								{   
							    	$UpdateDate67 = array(
        									'part_id' 			=> $part_id,
        									'operation_id' 		=> $op_id,
        									'mast_dpr_id' 	    => $mast_id,
        						            'year' 				=>  $_SESSION['current_year'],
        						            'doc_year' 			=>  $_SESSION['current_year'],
        									'issue_qty' 		=> ($available_qty>$dpr_qty)?$dpr_qty:$available_qty,
        							    	//'issue_qty' 		=> ($dpr_qty != "") ? $dpr_qty : 0,
        									'year' 				=> $_SESSION['current_year'],
        									'branch_id' 		=> $_SESSION['branch_id'],
        									'move_from'             => "B".$_SESSION['branch_id'],
        				                    'move_to'               => "B".$this->input->post('branch_id'),
        									'created_by' 		=> $_SESSION['id'],
        									'updated_by' 		=> $_SESSION['id'],
        									'issue_doc_id' 		=> $partMovementId,
        									'issue_doc_type' 	=> 'p_movement'
								    );
								
									$result16 = $this->db->insert('tran_dpr_stock',$UpdateDate67);
									
									
								}else{
								    
								    $UpdateDate67 = array(
        									'part_id' 			    => $part_id,
        									'op_id' 		        => $op_id,
        									'mast_partsrcir_id' 	=> $mast_partsrcir_id,
        									'det_partsrcir_id' 	    => $mast_id,
        						            'year' 				    =>  $_SESSION['current_year'],
        						            'doc_year' 			    =>  $_SESSION['current_year'],
        									'issue_qty' 		=> ($available_qty>$dpr_qty)?$dpr_qty:$available_qty,
        									'year' 				    => $_SESSION['current_year'],
        									'branch_id' 	    	=> $_SESSION['branch_id'],
        									'move_from'             => "B".$_SESSION['branch_id'],
        				                    'move_to'               => "B".$this->input->post('branch_id'),
        									'created_by' 		    => $_SESSION['id'],
        									'updated_by' 		    => $_SESSION['id'],
        									'issue_doc_id' 		    => $partMovementId,
        									'issue_doc_type' 	    => 'p_movement'
								    );
								    
									$result16 = $this->db->insert('tran_partsrcir_stock',$UpdateDate67);
								}

							 $used_qty =($available_qty>$dpr_qty)?$dpr_qty:$available_qty;
                                 $dpr_qty =$dpr_qty - $used_qty;
                                if ($dpr_qty<=0)
                                {break;}
							
							} //updatePartOpStock foreach End
							
			$postDate = array(
				'supplier_id' 		=> 0 ,
				'branch_id'			=> $this->input->post('branch_id'),
				'date'			    => $this->input->post('date'),
				'year'				=> $_SESSION['current_year'],
				'challan_date' 	    => $this->input->post('date'),
				'challan_no' 	     => 'p_movement',
				'created_by ' 		=> $_SESSION['id'],
				'created_on ' 		=> date("Y-m-d"),
				);
				
			$mast_partsrcir_id  =  $this->PartsMovementModel->AddTranPartsrcirMast($postDate);
			  $postDetails = array(
        				'mast_partsrcir_id' 	=> $mast_partsrcir_id,
        				'tran_partspo_det_id' 	=> 0,
        				'dc_det_id' 	        => 0,
        				'part_id' 			    => $part_id,
        				'op_id' 		        => $op_id,
        				'qty' 				    => $this->input->post('quantity'),
        				'qty_in_kgs' 		    => 0,
        				'inprocess_loss_qty' 	=> 0,
        				'qc_checked_by'         => '999999',
        				'qc_remarks'            =>'p_movement',
        				'qc_checked_on'         => date("Y-m-d H:i:s"),
        				'year ' 		        => $_SESSION['current_year'],
        				'created_by ' 		    => $_SESSION['id'],
        				'created_on ' 		    => date("Y-m-d H:i:s"),
        				);

				$det_partsrcir_id = $this->PartsMovementModel->AddTranPartsrcirDetails($postDetails);
			
							 $UpdateDate68 = array(
        									'part_id' 			    => $part_id,
        									'op_id' 		        => $op_id,
        									'mast_partsrcir_id' 	=> $mast_partsrcir_id,
        									'det_partsrcir_id' 	    => $det_partsrcir_id,
        						            'year' 				    =>  $_SESSION['current_year'],
        						            'doc_year' 			    =>  $_SESSION['current_year'],
        									'received_qty' 		    => $this->input->post('quantity'),
        									'year' 				    => $_SESSION['current_year'],
        									'branch_id' 	    	=> $this->input->post('branch_id'),
        									'move_from'             => "B".$_SESSION['branch_id'],
        				                    'move_to'               => "B".$this->input->post('branch_id'),
        									'created_by' 		    => $_SESSION['id'],
        									'updated_by' 		    => $_SESSION['id'],
        									'received_doc_id' 		    => $partMovementId,
        									'received_doc_type' 	    => 'p_movement'
								    );
								    
									$result16 = $this->db->insert('tran_partsrcir_stock',$UpdateDate68);

						 } //updatePartOpStock id				
							
			redirect('/PartsMovement');

		}else
		 {
		    
			$this->add();
		}
	}
	public function update(){
	 $this->session->unset_userdata('createS');
		$this->form_validation->set_rules('quantity', 'Qty', 'trim|required');
		$this->form_validation->set_error_delimiters('<div class="text-danger" style="text-align: left;margin-left: 5px;">', '</div>');
     
		if ($this->form_validation->run() == TRUE) {
		    $postDate = array(
				'qty' => $this->input->post('quantity'),
				'updated_by ' => $_SESSION['id'],
				'updated_on ' => date("Y-m-d"),
				);
			$editid=$_POST['editID'];
			$branch_id=$_POST['branch_id'];
		
			 $partMovementId=$this->PartsMovementModel->updatedtranPMovement($postDate,$editid);
			
             $dataarray=array('issue_qty' => '0');
	         $where=array('issue_doc_id'=>$editid,'issue_doc_type'=>'p_movement');
	         $res1 = $this->db->update('tran_dpr_stock',$dataarray,$where);

	         $res2 = $this->db->update('tran_partsrcir_stock',$dataarray,$where);

             $dataarray1=array('received_qty' =>'0');
	         $where1=array('received_doc_id'=>$editid,'received_doc_type'=>'p_movement','branch_id'=>$branch_id);
	         $res3 = $this->db->update('tran_partsrcir_stock',$dataarray1,$where1);
			
			if($partMovementId){
			 	 $this->session->set_flashdata('createS', 'Quantity Updated successfully.');
			}else{
			     $this->session->set_flashdata('createS', 'Error While Updating record.');
			}
		   
		}else{ 
		    $this->session->set_flashdata('createS', 'Enter Quantity...');
		}
		redirect('/addPartsMovement?ID='. base64_encode($editid)); 
	}
	
	public function deleteRMMovement()
	{
	   $rm_id = $_POST['rmId'];
	   $getRmAvailStock = $this->getQueryModel->getRmAvailStock($rm_id );
	   foreach ($getRmAvailStock as $key => $value) 
            {
           echo $mast_rmrcir_id = $value['mast_id'];
           echo "<br>";
          echo  $det_rmrcir_id  = $value['det_id'];
            }
	}
	//created by Asharani for Parts Movement Print- 28/06/2023
	public function partMvmtPrint(){
	    $id = base64_decode($_GET['ID']);
    	$data['companyDetails']     = $this->getQueryModel->companyDetails();
         $data['getPartMovement']        = $this->getQueryModel->getPartMovement($id);
    	
		$this->load->view('PartsMovement/partMvmtPrint',$data);
	}
	
}

?>