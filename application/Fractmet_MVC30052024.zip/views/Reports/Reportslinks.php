 <li class="breadcrumb-item"><a href="<?php echo base_url('MangDashboard');?>">Home</a></li>
<li class="breadcrumb-item"><a href="<?php echo base_url('Reports');?>">Reports</a></li>